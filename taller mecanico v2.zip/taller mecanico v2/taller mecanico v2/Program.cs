﻿using System;

namespace taller_mecanico_v2
{
    class Program
    {
        static void Main(string[] args)
        {
            string opcion;
            do
            {
                Console.Clear();
                Console.WriteLine("=== SISTEMA TALLER MECÁNICO ===");
                Console.WriteLine("1. Gestionar Mecánicos");
                Console.WriteLine("2. Gestionar Clientes");
                Console.WriteLine("3. Gestionar Reparaciones");
                Console.WriteLine("4. Gestionar Vehículos");
                Console.WriteLine("5. Salir");
                Console.Write("Seleccione una opción: ");
                opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        MenuMecanicos();
                        break;
                    case "2":
                        MenuClientes();
                        break;
                    case "3":
                        MenuReparaciones();
                        break;
                    case "4":
                        MenuVehiculos();
                        break;
                    case "5":
                        Console.WriteLine("Saliendo del sistema...");
                        break;
                    default:
                        Console.WriteLine("Opción no válida.");
                        break;
                }

                if (opcion != "5")
                {
                    Console.WriteLine("\nPresione una tecla para continuar...");
                    Console.ReadKey();
                }

            } while (opcion != "5");
        }

        static void MenuMecanicos()
        {
            string opcion;
            do
            {
                Console.Clear();
                Console.WriteLine("=== GESTIÓN DE MECÁNICOS ===");
                Console.WriteLine("1. Agregar Mecánico");
                Console.WriteLine("2. Ver Mecánicos");
                Console.WriteLine("3. Actualizar Mecánico");
                Console.WriteLine("4. Eliminar Mecánico");
                Console.WriteLine("5. Volver");
                Console.Write("Seleccione una opción: ");
                opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        MecanicoServicio.Agregar();
                        break;
                    case "2":
                        MecanicoServicio.Ver();
                        break;
                    case "3":
                        MecanicoServicio.Actualizar();
                        break;
                    case "4":
                        MecanicoServicio.Eliminar();
                        break;
                }

            } while (opcion != "5");
        }

        static void MenuClientes()
        {
            string opcion;
            do
            {
                Console.Clear();
                Console.WriteLine("=== GESTIÓN DE CLIENTES ===");
                Console.WriteLine("1. Agregar Cliente");
                Console.WriteLine("2. Ver Clientes");
                Console.WriteLine("3. Actualizar Cliente");
                Console.WriteLine("4. Eliminar Cliente");
                Console.WriteLine("5. Volver");
                Console.Write("Seleccione una opción: ");
                opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        ClienteService.Agregar();
                        break;
                    case "2":
                        ClienteService.Ver();
                        break;
                    case "3":
                        ClienteService.Actualizar();
                        break;
                    case "4":
                        ClienteService.Eliminar();
                        break;
                }

            } while (opcion != "5");
        }

        static void MenuReparaciones()
        {
            string opcion;
            do
            {
                Console.Clear();
                Console.WriteLine("=== GESTIÓN DE REPARACIONES ===");
                Console.WriteLine("1. Agregar Reparación");
                Console.WriteLine("2. Ver Reparaciones");
                Console.WriteLine("3. Actualizar Reparación");
                Console.WriteLine("4. Eliminar Reparación");
                Console.WriteLine("5. Volver");
                Console.Write("Seleccione una opción: ");
                opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        ReparacionService.Agregar();
                        break;
                    case "2":
                        ReparacionService.Ver();
                        break;
                    case "3":
                        ReparacionService.Actualizar();
                        break;
                    case "4":
                        ReparacionService.Eliminar();
                        break;
                }

            } while (opcion != "5");
        }

        static void MenuVehiculos()
        {
            string opcion;
            do
            {
                Console.Clear();
                Console.WriteLine("=== GESTIÓN DE VEHÍCULOS ===");
                Console.WriteLine("1. Agregar Vehículo");
                Console.WriteLine("2. Ver Vehículos");
                Console.WriteLine("3. Actualizar Vehículo");
                Console.WriteLine("4. Eliminar Vehículo");
                Console.WriteLine("5. Volver");
                Console.Write("Seleccione una opción: ");
                opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        VehiculoServicio.Agregar();
                        break;
                    case "2":
                        VehiculoServicio.Ver();
                        break;
                    case "3":
                        VehiculoServicio.Actualizar();
                        break;
                    case "4":
                        VehiculoServicio.Eliminar();
                        break;
                }

            } while (opcion != "5");
        }
    }
}
