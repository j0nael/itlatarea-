﻿using Microsoft.EntityFrameworkCore;
using taller_mecanico_v2.dbcontext;

namespace taller_mecanico_v2
{
    public class MecanicoServicio
    {
       public static void Agregar()
        {
            Console.WriteLine("Ingrese el nombre del mecánico:");
            string nombre = Console.ReadLine() ?? "SinNombre";

            Console.WriteLine("Ingrese la especialidad del mecánico:");
            string especialidad = Console.ReadLine() ?? "SinEspecialidad";

            Mecanico mecanico = new Mecanico(nombre, especialidad);

            using var conexion = new Conexion(new DbContextOptionsBuilder<Conexion>().Options);
            conexion.Mecanicos.Add(mecanico);
            conexion.SaveChanges();
           
            Console.WriteLine("Mecánico agregado correctamente.");
        }

        public static void Ver()
        {
            using var conexion = new Conexion(new DbContextOptionsBuilder<Conexion>().Options);
            var mecanicos = conexion.Mecanicos.ToList();

            Console.WriteLine("=== Lista de Mecánicos ===");
            foreach (var m in mecanicos)
            {
                Console.WriteLine($"ID: {m.Id}, Nombre: {m.Nombre}, Especialidad: {m.Especialidad}");
            }
        }

        public static void Actualizar()
        {
            using var conexion = new Conexion(new DbContextOptionsBuilder<Conexion>().Options);
            Console.Write("Ingrese el ID del mecánico a actualizar: ");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                var mecanico = conexion.Mecanicos.Find(id);
                if (mecanico != null)
                {
                    Console.Write("Nuevo nombre: ");
                    mecanico.Nombre = Console.ReadLine() ??mecanico.Nombre;

                    Console.Write("Nueva especialidad: ");
                    mecanico.Especialidad = Console.ReadLine() ?? mecanico.Especialidad;

                    conexion.SaveChanges();
                    Console.WriteLine("Mecánico actualizado.");
                }
                else
                {
                    Console.WriteLine("Mecánico no encontrado.");
                }
            }
            else
            {
                Console.WriteLine("ID inválido.");
            }
        }

        public static void Eliminar()
        {
            using var conexion = new Conexion(new DbContextOptionsBuilder<Conexion>().Options);
            Console.Write("Ingrese el ID del mecánico a eliminar: ");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                var mecanico = conexion.Mecanicos.Find(id);
                if (mecanico != null)
                {
                    conexion.Mecanicos.Remove(mecanico);
                    conexion.SaveChanges();
                    Console.WriteLine("Mecánico eliminado.");
                }
                else
                {
                    Console.WriteLine("Mecánico no encontrado.");
                }
            }
            else
            {
                Console.WriteLine("ID inválido.");
            }
        }
    }




}

