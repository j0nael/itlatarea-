﻿using System;
using System.Linq;
using taller_mecanico_v2.dbcontext;

public class ClienteService
{
    public static void Agregar()
    {
        Console.Write("Nombre: ");
        string nombre = Console.ReadLine();
        Console.Write("Teléfono: ");
        string telefono = Console.ReadLine();
        Console.Write("Correo: ");
        string correo = Console.ReadLine();

        var cliente = new Cliente { Nombre = nombre, Telefono = telefono, Correo = correo };

        using var db = new Conexion();
        db.Clientes.Add(cliente);
        db.SaveChanges();

        Console.WriteLine("Cliente agregado.");
    }

    public static void Ver()
    {
        using var db = new Conexion();
        var clientes = db.Clientes.ToList();

        foreach (var c in clientes)
        {
            Console.WriteLine($"ID: {c.Id}, Nombre: {c.Nombre}, Tel: {c.Telefono}, Correo: {c.Correo}");
        }
    }

    public static void Actualizar()
    {
        Console.Write("ID del cliente a actualizar: ");
        int id = int.Parse(Console.ReadLine());

        using var db = new Conexion();
        var cliente = db.Clientes.Find(id);

        if (cliente == null)
        {
            Console.WriteLine("Cliente no encontrado.");
            return;
        }

        Console.Write("Nuevo nombre: ");
        cliente.Nombre = Console.ReadLine() ?? cliente.Nombre;
        Console.Write("Nuevo teléfono: ");
        cliente.Telefono = Console.ReadLine() ?? cliente.Telefono;
        Console.Write("Nuevo correo: ");
        cliente.Correo = Console.ReadLine() ?? cliente.Correo;

        db.SaveChanges();
        Console.WriteLine("Cliente actualizado.");
    }

    public static void Eliminar()
    {
        Console.Write("ID del cliente a eliminar: ");
        int id = int.Parse(Console.ReadLine());

        using var db = new Conexion();
        var cliente = db.Clientes.Find(id);

        if (cliente == null)
        {
            Console.WriteLine("Cliente no encontrado.");
            return;
        }

        db.Clientes.Remove(cliente);
        db.SaveChanges();
        Console.WriteLine("Cliente eliminado.");
    }
}
