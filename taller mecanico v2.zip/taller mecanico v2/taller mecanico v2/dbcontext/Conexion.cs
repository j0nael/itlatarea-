﻿using Microsoft.EntityFrameworkCore;
using taller_mecanico_v2; 

namespace taller_mecanico_v2.dbcontext
{
    public class Conexion : DbContext
    {
        public Conexion() { }

        public Conexion(DbContextOptions options) : base(options) { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(
                    "Persist Security Info=False;Trusted_Connection=True;database=Mecanico;server=(local);TrustServerCertificate=True"
                );
            }
        }

        public DbSet<Mecanico> Mecanicos { get; set; }

        public DbSet<Cliente> Clientes { get; set; }

        public DbSet<Reparacion> Reparaciones { get; set; }

        public DbSet<Vehiculo> Vehiculos { get; set; }
    }
}
